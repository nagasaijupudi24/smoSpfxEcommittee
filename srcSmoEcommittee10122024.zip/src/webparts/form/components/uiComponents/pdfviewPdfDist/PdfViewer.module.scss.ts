/* tslint:disable */
require("./PdfViewer.module.css");
const styles = {
  welcome: 'welcome_65b9ee2f',
  welcomeImage: 'welcomeImage_65b9ee2f',
  pdfviewer: 'pdfviewer_65b9ee2f',
  links: 'links_65b9ee2f',
  pdfContainer: 'pdfContainer_65b9ee2f',
  pdfbutton: 'pdfbutton_65b9ee2f',
  toolbar: 'toolbar_65b9ee2f',
  toolbarContainer: 'toolbarContainer_65b9ee2f',
  toolbarViewer: 'toolbarViewer_65b9ee2f',
  toolbarViewerLeft: 'toolbarViewerLeft_65b9ee2f',
  toolbarViewerMiddle: 'toolbarViewerMiddle_65b9ee2f',
  toolbarViewerRight: 'toolbarViewerRight_65b9ee2f',
  toolbarButton: 'toolbarButton_65b9ee2f',
  toolbarLabel: 'toolbarLabel_65b9ee2f',
  splitToolbarButton: 'splitToolbarButton_65b9ee2f',
  dropdownToolbarButton: 'dropdownToolbarButton_65b9ee2f',
  select: 'select_65b9ee2f',
  pdfViewer: 'pdfViewer_65b9ee2f',
  page: 'page_65b9ee2f',
  pdfViewerContainer: 'pdfViewerContainer_65b9ee2f',
  shadow: 'shadow_65b9ee2f',
  toolbarLeft: 'toolbarLeft_65b9ee2f',
  toolbarMiddle: 'toolbarMiddle_65b9ee2f',
  toolbarRight: 'toolbarRight_65b9ee2f'
};

export default styles;
/* tslint:enable */