import * as React from 'react';
interface IAdobePdfViewerProps {
    clientId: string;
    fileUrl: string;
    defaultViewMode: string;
}
declare const AdobePdfViewer: React.FC<IAdobePdfViewerProps>;
export default AdobePdfViewer;
//# sourceMappingURL=adobepdf.d.ts.map