import * as React from "react";
interface TitleProps {
    itemId: any;
    statusOfRequest: string;
    propPaneformType: any;
    title: any;
}
declare const Title: React.FC<TitleProps>;
export default Title;
//# sourceMappingURL=title.d.ts.map