import * as React from "react";
declare const PDFViewer: React.FC<{
    pdfPath: string;
    noteNumber: string;
}>;
export default PDFViewer;
//# sourceMappingURL=pdfDist.d.ts.map