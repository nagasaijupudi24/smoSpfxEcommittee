declare const styles: {
    welcome: string;
    welcomeImage: string;
    pdfviewer: string;
    links: string;
    pdfContainer: string;
    pdfbutton: string;
    toolbar: string;
    toolbarContainer: string;
    toolbarViewer: string;
    toolbarViewerLeft: string;
    toolbarViewerMiddle: string;
    toolbarViewerRight: string;
    toolbarButton: string;
    toolbarLabel: string;
    splitToolbarButton: string;
    dropdownToolbarButton: string;
    select: string;
    pdfViewer: string;
    page: string;
    pdfViewerContainer: string;
    shadow: string;
    toolbarLeft: string;
    toolbarMiddle: string;
    toolbarRight: string;
};
export default styles;
//# sourceMappingURL=PdfViewer.module.scss.d.ts.map