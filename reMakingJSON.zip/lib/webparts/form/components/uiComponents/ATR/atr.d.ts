import * as React from "react";
interface IDropdownOption {
    id: any;
    key: any;
    text: any;
    email: any;
}
interface IATRAssigneeProps {
    _atrJoinedCommentsToDTO: any;
    atrType: any;
    getATRTypeOnChange: any;
    clearAtrGridDataOnSelectionOFATRType: any;
    checkingCurrentATRCreatorisCurrentApproverOrNot: any;
    getATRJoinedComments: any;
    updategirdData: any;
    commentsData: any;
    sp: any;
    context: any;
    artCommnetsGridData: any;
    deletedGridData: any;
    approverDetails: any;
    currentATRCreatorDetails: any;
}
interface IATRAssigneeState {
    tableData: any;
    selectedUsers: any;
    currentRowKey: any;
    selectedStatus: any;
    selectedValue: any;
    commentsData: any;
    isModalOpen: boolean;
    modalMessage: string;
    clearPeoplePicker: any;
    atrJoinedComments: any;
    selectedChoice: any;
    selectedDropDownValue: any;
    isDisabled: boolean;
    statusOptions: IDropdownOption[];
}
export declare class ATRAssignee extends React.Component<IATRAssigneeProps, IATRAssigneeState> {
    constructor(props: IATRAssigneeProps);
    componentDidMount(): void;
    private _updateStatusOptions;
    private columns;
    private handleStatusChange;
    private handleRowClick;
    private handleDeleteRow;
    _getDetailsFromPeoplePicker: () => any;
    _getDetailsFromPeoplePickerData: (data: any, type: any) => any;
    private _closeModal;
    private onChoiceChange;
    render(): React.ReactElement<IATRAssigneeProps>;
}
export {};
//# sourceMappingURL=atr.d.ts.map