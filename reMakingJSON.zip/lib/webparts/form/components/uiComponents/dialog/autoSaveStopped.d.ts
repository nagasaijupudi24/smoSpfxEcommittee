import React from 'react';
interface AutoSaveDialogProps {
    hidden: boolean;
    onDismiss: () => void;
}
declare const AutoSaveDialog: React.FC<AutoSaveDialogProps>;
export default AutoSaveDialog;
//# sourceMappingURL=autoSaveStopped.d.ts.map