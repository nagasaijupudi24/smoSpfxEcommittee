import * as React from 'react';
import { IExampleItem } from '@fluentui/example-data';
import { IColumn } from '@fluentui/react/lib/DetailsList';
export interface IDetailsListCustomColumnsExampleState {
    sortedItems: IExampleItem[];
    columns: IColumn[];
}
export declare class DetailsListCustomColumnsExample extends React.Component<{}, IDetailsListCustomColumnsExampleState> {
    constructor(props: {});
    render(): JSX.Element;
    private _onColumnClick;
    private _buildColumns;
    private _onColumnHeaderContextMenu;
}
//# sourceMappingURL=detailsList.d.ts.map