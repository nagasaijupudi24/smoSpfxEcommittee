import * as React from 'react';
import { IColumn } from '@fluentui/react/lib/DetailsList';
interface IDetailsListDragDropExampleState {
    items: any;
    columns: IColumn[];
}
export declare class DetailsListDragDropExample extends React.Component<any, IDetailsListDragDropExampleState> {
    private _selection;
    private _dragDropEvents;
    private _draggedItem;
    private _draggedIndex;
    private _columns;
    private _remove;
    constructor(props: any);
    componentDidMount(): void;
    render(): JSX.Element;
    private _getDragDropEvents;
    private _insertBeforeItem;
}
export {};
//# sourceMappingURL=dragAndDropFluent.d.ts.map