/// <reference types="react" />
declare const CommentsLogTable: (props: any) => JSX.Element;
export default CommentsLogTable;
//# sourceMappingURL=commentsTable.d.ts.map