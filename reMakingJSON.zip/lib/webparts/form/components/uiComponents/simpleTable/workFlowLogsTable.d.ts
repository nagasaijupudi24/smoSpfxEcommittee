/// <reference types="react" />
declare const WorkFlowLogsTable: (props: any) => JSX.Element;
export default WorkFlowLogsTable;
//# sourceMappingURL=workFlowLogsTable.d.ts.map