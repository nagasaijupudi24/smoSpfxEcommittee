import * as React from "react";
interface IATRAssigneeProps {
    updategirdData: any;
    sp: any;
    context: any;
    artCommnetsGridData: any;
    submitFunctionForMarkInfo: any;
    deletedGridData: any;
    homePageUrl: any;
}
interface IATRAssigneeState {
    submitBtnVisable: any;
    tableData: any;
    selectedUsers: any;
    currentRowKey: any;
    selectedStatus: any;
    selectedValue: any;
    isModalOpen: boolean;
    modalMessage: string;
    clearPeoplePicker: any;
    warnType: any;
}
export declare class MarkInfo extends React.Component<IATRAssigneeProps, IATRAssigneeState> {
    constructor(props: IATRAssigneeProps);
    private columns;
    private handleDeleteRow;
    _handleAdd: () => any;
    _getDetailsFromPeoplePickerData: (data: any, type: any) => any;
    private _closeModal;
    private _handleSubmit;
    render(): React.ReactElement<IATRAssigneeProps>;
}
export {};
//# sourceMappingURL=markInfo.d.ts.map