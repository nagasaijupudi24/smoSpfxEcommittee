import * as React from "react";
export interface IUploadFileProps {
    cummulativeError: any;
    typeOfDoc: string;
    onChange: (files: File[] | null, typeOfDoc: string) => void;
    accept?: string;
    maxFileSizeMB: number;
    multiple: boolean;
    data: File[];
    errorData: any;
    addtionalData: any[];
}
interface IFileWithError {
    id: string;
    file: File;
    error: string | null;
    cumulativeError: any;
}
interface IUploadFileState {
    selectedFiles: IFileWithError[];
    cummError: string | null;
    errorOfFile: any;
}
export default class SupportingDocumentsUploadFileComponent extends React.Component<IUploadFileProps, IUploadFileState> {
    private fileInputRef;
    constructor(props: IUploadFileProps);
    componentDidMount(): void;
    componentDidUpdate(prevProps: IUploadFileProps): void;
    private isFileNameValid;
    private validateFiles;
    private handleFileChange;
    private convertToFileArrayBuffer;
    private handleDeleteFile;
    render(): React.ReactElement<IUploadFileProps>;
}
export {};
//# sourceMappingURL=supportingDocuments.d.ts.map