import * as React from "react";
interface MyModalProps {
    hidden: boolean;
    handleDialogBox: () => void;
}
declare const ReviewerExistModal: React.FC<MyModalProps>;
export default ReviewerExistModal;
//# sourceMappingURL=reviewerDialogAlreadyExist.d.ts.map