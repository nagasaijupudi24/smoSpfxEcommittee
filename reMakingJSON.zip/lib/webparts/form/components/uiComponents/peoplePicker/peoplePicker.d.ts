import * as React from "react";
import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IPnPPeoplePickerProps {
    disabled: any;
    context: WebPartContext;
    spProp: any;
    getDetails: any;
    typeOFButton: any;
    clearPeoplePicker: any;
}
export interface IPnPPeoplePickerState {
    selectedPeople: any[];
    key: any;
    peoplePickerData: any[];
}
export default class PnPPeoplePicker extends React.Component<IPnPPeoplePickerProps, IPnPPeoplePickerState> {
    constructor(props: IPnPPeoplePickerProps);
    private _clearPeoplePicker;
    private _getUserProperties;
    private _getPeoplePickerItems;
    render(): React.ReactElement<IPnPPeoplePickerProps>;
}
//# sourceMappingURL=peoplePicker.d.ts.map