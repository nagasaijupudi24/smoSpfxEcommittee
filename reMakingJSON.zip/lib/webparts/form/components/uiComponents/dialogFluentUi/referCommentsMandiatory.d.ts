import * as React from 'react';
declare const ReferCommentsMandatoryDialog: React.FC<{
    isVisibleAlter: boolean;
    onCloseAlter: () => void;
    statusOfReq: any;
}>;
export default ReferCommentsMandatoryDialog;
//# sourceMappingURL=referCommentsMandiatory.d.ts.map