import * as React from 'react';
interface IConfirmationDialogProps {
    hidden: boolean;
    onConfirm: () => void;
    onCancel: () => void;
    title: string;
    subText: string;
}
declare const ConfirmationDialog: React.FC<IConfirmationDialogProps>;
export default ConfirmationDialog;
//# sourceMappingURL=submitConfirmation.d.ts.map