import * as React from 'react';
declare const ChangeApproverMandatoryDialog: React.FC<{
    isVisibleAlter: boolean;
    onCloseAlter: () => void;
}>;
export default ChangeApproverMandatoryDialog;
//# sourceMappingURL=changeApproverMandiatory.d.ts.map