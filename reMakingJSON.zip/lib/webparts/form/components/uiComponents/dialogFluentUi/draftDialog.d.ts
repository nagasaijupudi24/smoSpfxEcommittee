import * as React from 'react';
interface IDraftSuccessDialogProps {
    hidden: boolean;
    onClose: () => void;
}
declare const DraftSuccessDialog: React.FC<IDraftSuccessDialogProps>;
export default DraftSuccessDialog;
//# sourceMappingURL=draftDialog.d.ts.map