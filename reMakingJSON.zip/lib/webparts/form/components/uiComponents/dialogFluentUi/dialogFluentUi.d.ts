import * as React from "react";
interface IDialogProps {
    changeApproverDataMandatory: any;
    referCommentsAndDataMandatory: any;
    statusNumberForChangeApprover: any;
    referDto: any;
    requesterEmail: any;
    dialogUserCheck: any;
    hiddenProp: any;
    dialogDetails: any;
    sp: any;
    context: any;
    fetchAnydata: any;
    fetchReferData: any;
    isUserExistingDialog: any;
}
export declare const DialogBlockingExample: React.FunctionComponent<IDialogProps>;
export {};
//# sourceMappingURL=dialogFluentUi.d.ts.map