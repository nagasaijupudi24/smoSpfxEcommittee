import * as React from 'react';
declare const AutoSaveFailedDialog: React.FC<{
    isVisibleAlter: boolean;
    onCloseAlter: () => void;
    statusOfReq: any;
}>;
export default AutoSaveFailedDialog;
//# sourceMappingURL=autoSaveFailedDialog.d.ts.map