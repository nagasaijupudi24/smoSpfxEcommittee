import * as React from 'react';
declare const CummulativeErrorDialog: React.FC<{
    isVisibleAlter: boolean;
    onCloseAlter: () => void;
    statusOfReq: any;
}>;
export default CummulativeErrorDialog;
//# sourceMappingURL=cummulativeDialog.d.ts.map