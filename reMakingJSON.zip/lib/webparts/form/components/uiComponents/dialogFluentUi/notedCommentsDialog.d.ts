import * as React from 'react';
declare const NotedCommentDialog: React.FC<{
    isVisibleAlter: boolean;
    onCloseAlter: () => void;
    statusOfReq: any;
}>;
export default NotedCommentDialog;
//# sourceMappingURL=notedCommentsDialog.d.ts.map