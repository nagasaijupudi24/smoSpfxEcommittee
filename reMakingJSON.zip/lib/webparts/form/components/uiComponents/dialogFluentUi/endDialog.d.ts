import * as React from 'react';
declare const SuccessDialog: React.FC<{
    existUrl: any;
    isVisibleAlter: boolean;
    onCloseAlter: () => void;
    statusOfReq: any;
    typeOfNote: any;
}>;
export default SuccessDialog;
//# sourceMappingURL=endDialog.d.ts.map