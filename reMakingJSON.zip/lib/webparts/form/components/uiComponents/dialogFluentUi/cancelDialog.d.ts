import * as React from 'react';
interface IConfirmationDialogProps {
    hidden: boolean;
    onConfirm: () => void;
    onCancel: () => void;
}
declare const CancelConfirmationDialog: React.FC<IConfirmationDialogProps>;
export default CancelConfirmationDialog;
//# sourceMappingURL=cancelDialog.d.ts.map