import * as React from 'react';
declare const RejectBtnCommentCheckDialog: React.FC<{
    isVisibleAlter: boolean;
    onCloseAlter: () => void;
    statusOfReq: any;
}>;
export default RejectBtnCommentCheckDialog;
//# sourceMappingURL=rejectCommentsCheckDialog.d.ts.map