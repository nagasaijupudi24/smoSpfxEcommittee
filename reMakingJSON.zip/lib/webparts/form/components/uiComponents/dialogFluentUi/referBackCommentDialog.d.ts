import * as React from 'react';
declare const ReferBackCommentDialog: React.FC<{
    isVisibleAlter: boolean;
    onCloseAlter: () => void;
    statusOfReq: any;
}>;
export default ReferBackCommentDialog;
//# sourceMappingURL=referBackCommentDialog.d.ts.map