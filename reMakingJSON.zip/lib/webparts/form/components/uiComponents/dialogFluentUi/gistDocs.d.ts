import * as React from 'react';
declare const GistDocSubmitted: React.FC<{
    isVisibleAlter: boolean;
    onCloseAlter: () => void;
    statusOfReq: any;
    existUrl: any;
}>;
export default GistDocSubmitted;
//# sourceMappingURL=gistDocs.d.ts.map