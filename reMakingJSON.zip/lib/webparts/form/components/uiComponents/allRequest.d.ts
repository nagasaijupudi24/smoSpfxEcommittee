import * as React from 'react';
import { IAllRequestProps } from '../IAllRequestProps';
export interface IAllRequestStateProps {
    listItems: any;
}
export declare class AllRequest extends React.Component<IAllRequestProps, IAllRequestStateProps> {
    constructor(props: IAllRequestProps);
    render(): any;
}
//# sourceMappingURL=allRequest.d.ts.map