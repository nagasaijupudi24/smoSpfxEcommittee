import * as React from 'react';
declare const PageLoader: React.FunctionComponent;
export default PageLoader;
//# sourceMappingURL=Pageloder.d.ts.map